#!/usr/bin/env bash
# One-command deployment to SAP BTP Cloud Foundry. Run after: cf login
set -euo pipefail
cd "$(dirname "$0")"
UAA=iflow-inspector-uaa
API=iflow-inspector-api

cf target >/dev/null 2>&1 || { echo "Not logged in. Run: cf login -a <api-endpoint>"; exit 1; }

wait_for() {
  while true; do
    st=$(cf service "$1" | grep -i "status:" | head -1)
    echo "  $1 -> $st"
    echo "$st" | grep -qi "succeeded" && break
    echo "$st" | grep -qi "failed" && { echo "Service $1 failed. Check: cf service $1"; exit 1; }
    sleep 5
  done
}

echo "1/5 Services"
cf service "$UAA" >/dev/null 2>&1 || cf create-service xsuaa application "$UAA" -c xs-security.json
if ! cf service "$API" >/dev/null 2>&1; then
  cf create-service process-integration-runtime api "$API" \
    -c '{"grant-types":["client_credentials"],"roles":["WorkspacePackagesRead","MonitoringDataRead"]}'
fi
wait_for "$UAA"; wait_for "$API"

echo "2/5 Backend"
cf push -f manifest-srv.yml
SRV_URL=$(cf app iflow-inspector-srv | awk '/^routes:/ {print $2}')
echo "    backend: https://$SRV_URL"

echo "3/5 App router"
cf push -f manifest-approuter.yml --no-start

echo "4/5 Connect app router to backend"
cf set-env iflow-inspector-approuter destinations \
  "[{\"name\":\"srv-api\",\"url\":\"https://${SRV_URL}\",\"forwardAuthToken\":true}]" >/dev/null

echo "5/5 Start"
cf start iflow-inspector-approuter
APP_URL=$(cf app iflow-inspector-approuter | awk '/^routes:/ {print $2}')
echo
echo "Done. Open: https://$APP_URL"
echo "Then assign the role collection 'iFlow Inspector Viewer' to your user (BTP cockpit > Security > Users)."
