"""SAP Cloud Integration (Integration Suite) client and iFlow parser."""
import io
import json
import os
import re
import time
import zipfile
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from urllib.parse import quote, urlsplit

import requests


# ---------------------------------------------------------------- credentials
def load_credentials():
    """Credentials of the Process Integration Runtime (api) binding on Cloud Foundry,
    or CPI_* environment variables when running locally."""
    vcap = os.getenv("VCAP_SERVICES")
    if vcap:
        wanted = os.getenv("CPI_SERVICE_NAME", "iflow-inspector-api")
        found = []
        for _, instances in json.loads(vcap).items():
            for inst in instances:
                c = inst.get("credentials", {})
                if "xsappname" in c:      # skip the XSUAA binding
                    continue
                o = c.get("oauth", c)
                if "clientid" in o and "tokenurl" in o and (o.get("url") or c.get("url")):
                    found.append((inst.get("name"), (o.get("url") or c["url"], o["tokenurl"],
                                                     o["clientid"], o["clientsecret"])))
        for name, creds in found:
            if name == wanted:
                return creds
        if found:
            return found[0][1]
    return (os.environ["CPI_URL"], os.environ["CPI_TOKEN_URL"],
            os.environ["CPI_CLIENT_ID"], os.environ["CPI_CLIENT_SECRET"])


def normalize(url):
    p = urlsplit(url.strip())
    return f"{p.scheme}://{p.netloc}{p.path}".rstrip("/").lower()


# ----------------------------------------------------------------- API client
class CPI:
    def __init__(self, api_url, token_url, client_id, client_secret):
        self.base = api_url.rstrip("/") + "/api/v1"
        t = token_url.rstrip("/")
        self.token_url = t if t.endswith("/oauth/token") else t + "/oauth/token"
        self.auth = (client_id, client_secret)
        self._token, self._exp = None, 0
        self._pkg_cache = None

    def _headers(self, accept="application/json"):
        if not self._token or time.time() > self._exp - 60:
            r = requests.post(self.token_url, data={"grant_type": "client_credentials"},
                              auth=self.auth, timeout=30)
            r.raise_for_status()
            j = r.json()
            self._token, self._exp = j["access_token"], time.time() + int(j.get("expires_in", 3600))
        return {"Authorization": f"Bearer {self._token}", "Accept": accept}

    def get(self, path, accept="application/json"):
        r = requests.get(self.base + path, headers=self._headers(accept), timeout=60)
        r.raise_for_status()
        return r

    # --- lookup
    def find_iflow(self, endpoint_url):
        data = self.get("/ServiceEndpoints?$expand=EntryPoints").json()["d"]["results"]
        target = normalize(endpoint_url)
        for se in data:
            for ep in se["EntryPoints"]["results"]:
                if normalize(ep["Url"]) == target:
                    return se
        return None

    def find_by_name(self, text):
        data = self.get("/ServiceEndpoints").json()["d"]["results"]
        t = text.lower()
        return [s for s in data if t in s["Name"].lower() or t in s["Id"].lower()]

    def design_artifact(self, iflow_id):
        return self.get(f"/IntegrationDesigntimeArtifacts(Id='{iflow_id}',Version='active')").json()["d"]

    def _pkg_index(self):
        if self._pkg_cache is None:
            idx = []
            for p in self.get("/IntegrationPackages").json()["d"]["results"]:
                arts = self.get(f"/IntegrationPackages('{p['Id']}')/IntegrationDesigntimeArtifacts"
                                ).json()["d"]["results"]
                idx.append((p["Id"], p["Name"], {a["Id"] for a in arts}))
            self._pkg_cache = idx
        return self._pkg_cache

    def find_package(self, iflow_id):
        for pid, pname, ids in self._pkg_index():
            if iflow_id in ids:
                return pid, pname
        return None, None

    def download_iflow(self, iflow_id):
        r = self.get(f"/IntegrationDesigntimeArtifacts(Id='{iflow_id}',Version='active')/$value",
                     accept="application/octet-stream")
        return zipfile.ZipFile(io.BytesIO(r.content))

    def configurations(self, iflow_id):
        res = self.get(f"/IntegrationDesigntimeArtifacts(Id='{iflow_id}',Version='active')/Configurations"
                       ).json()["d"]["results"]
        return {c["ParameterKey"]: c["ParameterValue"] for c in res}

    def runtime_status(self, iflow_id):
        try:
            d = self.get(f"/IntegrationRuntimeArtifacts('{iflow_id}')").json()["d"]
            return {"status": d.get("Status"), "deployed_by": d.get("DeployedBy"),
                    "deployed_on": d.get("DeployedOn")}
        except requests.HTTPError:
            return None


# ------------------------------------------------------------------ iFlow XML
def _local(tag):
    return tag.split("}")[-1]


def _iflx_root(z):
    name = next(n for n in z.namelist() if n.endswith(".iflx"))
    return ET.fromstring(z.read(name))


def _own_props(el):
    props = {}
    for ext in el:
        if _local(ext.tag) == "extensionElements":
            for p in ext:
                if _local(p.tag) == "property":
                    k, v = p.find("key"), p.find("value")
                    if k is not None and k.text:
                        props[k.text] = v.text if v is not None else None
    return props


def resolve_placeholders(value, params):
    if not value or not isinstance(value, str):
        return value
    for k, v in params.items():
        value = value.replace("{{" + k + "}}", v or "")
    return value


def parse_iflow(z):
    """Adapter channels (messageFlow elements)."""
    out = []
    for el in _iflx_root(z).iter():
        if _local(el.tag) == "messageFlow":
            p = _own_props(el)
            out.append({
                "direction": p.get("direction"),
                "name": p.get("Name"),
                "adapter": p.get("ComponentType"),
                "transport": p.get("TransportProtocol"),
                "message_protocol": p.get("MessageProtocol"),
                "address": p.get("address") or p.get("httpAddressWithoutQuery"),
                "raw": p,
            })
    return out


STEP_LABELS = {
    "Enricher": "Content Modifier", "Script": "Script", "Mapping": "Mapping",
    "XmlToJsonConverter": "XML to JSON Converter", "JsonToXmlConverter": "JSON to XML Converter",
    "Splitter": "Splitter", "Gather": "Gather", "ExternalCall": "Request Reply / Content Enricher",
    "Send": "Send", "ProcessCallElement": "Process Call", "ExclusiveGateway": "Router",
    "ParallelGateway": "Multicast", "WriteVariables": "Write Variables", "Filter": "Filter",
    "Validator": "XML Validator", "Encryptor": "Encryptor", "Decryptor": "Decryptor",
    "Signer": "Signer", "Aggregator": "Aggregator", "StartEvent": "Start", "EndEvent": "End",
    "NonLoopingProcess": "Local Integration Process",
    "ErrorEventSubProcessTemplate": "Exception Subprocess",
}
NODE_TAGS = {"startEvent", "endEvent", "callActivity", "serviceTask", "task", "exclusiveGateway",
             "parallelGateway", "subProcess", "intermediateCatchEvent", "intermediateThrowEvent"}
SKIP_KEYS = {"componentVersion", "cmdVariantUri", "activityType", "subActivityType"}


def _table_rows(text):
    if not text or "<row" not in text:
        return text
    rows = []
    for row in re.findall(r"<row>(.*?)</row>", text, flags=re.S):
        rows.append({k: v for k, v in re.findall(r"<cell id='([^']*)'>(.*?)</cell>", row, flags=re.S)})
    return rows


def _walk(container, params):
    nodes, flows = {}, []
    for el in container:
        t = _local(el.tag)
        if t == "sequenceFlow":
            cond = next(((c.text or "").strip() for c in el if _local(c.tag) == "conditionExpression"), None)
            fp = _own_props(el)
            flows.append({"source": el.get("sourceRef"), "target": el.get("targetRef"),
                          "name": el.get("name"), "condition": cond or fp.get("conditionExpression"),
                          "default": fp.get("isDefault") == "true"})
        elif t in NODE_TAGS:
            p = _own_props(el)
            atype = p.get("activityType") or t
            node = {"id": el.get("id"), "name": el.get("name"), "element": t, "activity_type": atype,
                    "sub_type": p.get("subActivityType"),
                    "palette_step": STEP_LABELS.get(atype, atype), "config": {}}
            for k, v in p.items():
                if k in SKIP_KEYS:
                    continue
                v = resolve_placeholders(v, params)
                node["config"][k] = _table_rows(v) if k.endswith("Table") else v
            if t == "subProcess":
                node["steps"] = _walk(el, params)
            nodes[node["id"]] = node
    return {"nodes": nodes, "flows": flows}


def _order(graph):
    nodes, flows = graph["nodes"], graph["flows"]
    out_map = {}
    for f in flows:
        out_map.setdefault(f["source"], []).append(f)
    queue = [i for i, n in nodes.items() if n["element"] == "startEvent"]
    seen, ordered = set(), []
    while queue:
        nid = queue.pop(0)
        if nid in seen or nid not in nodes:
            continue
        seen.add(nid)
        n = dict(nodes[nid])
        branches = out_map.get(nid, [])
        if n["element"] == "exclusiveGateway":
            n["routes"] = [{"name": b["name"], "condition": b["condition"], "default": b["default"],
                            "goes_to": nodes.get(b["target"], {}).get("name")} for b in branches]
        if "steps" in n:
            n["steps"] = _order(n["steps"])
        ordered.append(n)
        queue.extend(b["target"] for b in branches)
    for nid, n in nodes.items():
        if nid not in seen:
            m = dict(n)
            if "steps" in m:
                m["steps"] = _order(m["steps"])
            ordered.append(m)
    for i, n in enumerate(ordered, 1):
        n["seq"] = i
    return ordered


def parse_steps(z, params=None):
    params = params or {}
    return [{"id": el.get("id"), "name": el.get("name"), "steps": _order(_walk(el, params))}
            for el in _iflx_root(z).iter() if _local(el.tag) == "process"]


def flatten(steps):
    for s in steps:
        yield s
        if "steps" in s:
            yield from flatten(s["steps"])


def list_resources(z, include_content=False, max_chars=5000):
    prefix, out = "src/main/resources/", []
    for n in z.namelist():
        if n.startswith(prefix) and not n.endswith("/") and "/scenarioflows/" not in n:
            item = {"path": n[len(prefix):], "size": z.getinfo(n).file_size}
            if include_content and n.endswith((".groovy", ".js", ".xsl", ".xslt", ".xsd", ".wsdl")):
                item["content"] = z.read(n).decode("utf-8", errors="replace")[:max_chars]
            out.append(item)
    return out


# -------------------------------------------------------------------- metrics
def _ms(v):
    m = re.search(r"/Date\((-?\d+)", v or "")
    return int(m.group(1)) if m else None


def _iso(ms):
    return datetime.fromtimestamp(ms / 1000, tz=timezone.utc).isoformat() if ms else None


def _pct(values, p):
    if not values:
        return None
    s = sorted(values)
    return s[min(len(s) - 1, int(round(p / 100 * (len(s) - 1))))]


def _error_text(cpi, guid):
    try:
        return cpi.get(f"/MessageProcessingLogs('{guid}')/ErrorInformation/$value", accept="text/plain").text
    except requests.RequestException:
        return None


def message_metrics(cpi, iflow_id, days=7, max_logs=5000, error_samples=10):
    since = (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%dT%H:%M:%S.000")
    flt = "IntegrationFlowName eq '%s' and LogStart ge datetime'%s'" % (iflow_id, since)
    logs, skip = [], 0
    while len(logs) < max_logs:
        path = ("/MessageProcessingLogs?$filter=" + quote(flt) +
                "&$orderby=LogStart%20desc&$top=1000&$skip=" + str(skip))
        batch = cpi.get(path).json()["d"]["results"]
        logs.extend(batch)
        if len(batch) < 1000:
            break
        skip += 1000
    truncated = len(logs) >= max_logs
    logs = logs[:max_logs]
    total = len(logs)

    by_status, durations, per_hour, per_day = {}, [], {}, {}
    for l in logs:
        st = l.get("Status")
        by_status[st] = by_status.get(st, 0) + 1
        s, e = _ms(l.get("LogStart")), _ms(l.get("LogEnd"))
        if st == "COMPLETED" and s and e:
            durations.append(e - s)
        if s:
            dt = datetime.fromtimestamp(s / 1000, tz=timezone.utc)
            h, d = dt.strftime("%Y-%m-%d %H:00"), dt.strftime("%Y-%m-%d")
            per_hour[h] = per_hour.get(h, 0) + 1
            per_day[d] = per_day.get(d, 0) + 1

    failed = [l for l in logs if l.get("Status") == "FAILED"]
    errs = {}
    for l in failed[:error_samples]:
        txt = (_error_text(cpi, l["MessageGuid"]) or "").strip()
        key = txt.splitlines()[0][:200] if txt else "No error text available"
        errs[key] = errs.get(key, 0) + 1

    def rate(n):
        return round(100.0 * n / total, 2) if total else None

    return {
        "period_days": days, "total_messages": total, "truncated": truncated, "by_status": by_status,
        "success_rate_pct": rate(by_status.get("COMPLETED", 0)),
        "failure_rate_pct": rate(by_status.get("FAILED", 0)),
        "processing_time_ms": {
            "avg": round(sum(durations) / len(durations), 1) if durations else None,
            "min": min(durations) if durations else None, "max": max(durations) if durations else None,
            "median": _pct(durations, 50), "p95": _pct(durations, 95)},
        "volume": {
            "avg_per_day": round(total / days, 1) if days else None,
            "peak_per_hour": max(per_hour.values()) if per_hour else 0,
            "peak_hour": max(per_hour, key=per_hour.get) if per_hour else None,
            "peak_per_day": max(per_day.values()) if per_day else 0},
        "last_execution": {"time": _iso(_ms(logs[0].get("LogStart"))), "status": logs[0].get("Status")} if logs else None,
        "last_failure": {"time": _iso(_ms(failed[0].get("LogStart"))), "message_guid": failed[0].get("MessageGuid")} if failed else None,
        "top_errors": [{"error": k, "count": v} for k, v in sorted(errs.items(), key=lambda x: -x[1])],
    }


def design_metrics(cpi, iflow_id, processes, adapters, resources, params):
    d = cpi.design_artifact(iflow_id)
    steps = [s for p in processes for s in flatten(p["steps"])]
    by_type = {}
    for s in steps:
        by_type[s["palette_step"]] = by_type.get(s["palette_step"], 0) + 1
    scripts = sum(1 for r in resources if r["path"].startswith("script/"))
    mappings = sum(1 for r in resources if r["path"].startswith("mapping/"))
    routers, receivers = by_type.get("Router", 0), sum(1 for a in adapters if a["direction"] == "Receiver")
    score = len(steps) + 3 * scripts + 2 * mappings + 2 * routers + 2 * receivers
    return {
        "design": {"version": d.get("Version"), "package_id": d.get("PackageId"),
                   "description": d.get("Description"), "sender": d.get("Sender"),
                   "receiver": d.get("Receiver"), "created_by": d.get("CreatedBy"),
                   "created_at": _iso(_ms(d.get("CreatedAt"))), "modified_by": d.get("ModifiedBy"),
                   "modified_at": _iso(_ms(d.get("ModifiedAt")))},
        "complexity": {
            "total_steps": len(steps), "steps_by_palette_type": by_type, "scripts": scripts,
            "mappings": mappings, "routers": routers, "receivers": receivers,
            "local_processes": sum(1 for s in steps if s["activity_type"] == "NonLoopingProcess"),
            "externalized_parameters": len(params),
            "has_exception_subprocess": any(s["activity_type"] == "ErrorEventSubProcessTemplate" for s in steps),
            "score": score, "label": "Low" if score < 15 else "Medium" if score < 40 else "High"},
    }


# -------------------------------------------------------------- orchestration
def inspect_iflow(cpi, endpoint=None, iflow_id=None, include_raw=False, include_scripts=False,
                  include_metrics=True, days=7):
    if iflow_id:
        iflow_id = iflow_id.split("$")[0]
        d = cpi.design_artifact(iflow_id)
        se = {"Id": iflow_id, "Name": d.get("Name"), "Version": d.get("Version")}
    else:
        se = cpi.find_iflow(endpoint)
        if not se:
            return {"error": "No iFlow found for this endpoint. Use /search or pass iflow_id."}
    iid = se["Id"].split("$")[0]  # ServiceEndpoints Id looks like "MyFlow$endpointAddress=path"
    pkg_id, pkg_name = cpi.find_package(iid)
    z = cpi.download_iflow(iid)
    try:
        params = cpi.configurations(iid)
    except requests.HTTPError:
        params = {}
    adapters = parse_iflow(z)
    for a in adapters:
        a["address"] = resolve_placeholders(a["address"], params)
    processes = parse_steps(z, params)
    resources = list_resources(z, include_content=include_scripts)
    result = {
        "artifact_id": iid, "artifact_name": se["Name"], "version": se["Version"],
        "package_id": pkg_id, "package_name": pkg_name, "runtime": cpi.runtime_status(iid),
        "senders": [a for a in adapters if a["direction"] == "Sender"],
        "receivers": [a for a in adapters if a["direction"] == "Receiver"],
        "processes": processes, "resources": resources, "parameters": params,
    }
    if include_metrics:
        result["metrics"] = {"deployment": result["runtime"],
                             **design_metrics(cpi, iid, processes, adapters, resources, params),
                             "runtime": message_metrics(cpi, iid, days=days)}
    if not include_raw:
        for a in result["senders"] + result["receivers"]:
            a.pop("raw", None)
    return result
