import io
import json

import requests
from fastapi import Depends, FastAPI, HTTPException, Query, Request
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from openpyxl import Workbook

from cpi import CPI, inspect_iflow, load_credentials, message_metrics
from auth import require_auth
from iface_profile import build_profile

app = FastAPI(title="iFlow Inspector", dependencies=[Depends(require_auth)])
app.mount("/static", StaticFiles(directory="static"), name="static")
_cpi = None


def get_cpi():
    global _cpi
    if _cpi is None:
        _cpi = CPI(*load_credentials())
    return _cpi


def _run(fn, *a, **kw):
    try:
        result = fn(get_cpi(), *a, **kw)
    except requests.HTTPError as e:
        code = e.response.status_code if e.response is not None else 502
        hint = " (check service key roles)" if code == 403 else ""
        raise HTTPException(status_code=502, detail=f"Cloud Integration API error {code}{hint}: {e}")
    if isinstance(result, dict) and "error" in result:
        raise HTTPException(status_code=404, detail=result["error"])
    return result


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/me")
def me(request: Request):
    return {"user": getattr(request.state, "user", None)}


@app.get("/")
def home():
    return FileResponse("static/index.html")


@app.get("/inspect")
def inspect_endpoint(
    endpoint: str = Query(None, description="iFlow runtime endpoint URL"),
    iflow_id: str = Query(None, description="iFlow ID (for iFlows without an HTTP endpoint)"),
    raw: bool = False, scripts: bool = False, metrics: bool = True,
    days: int = Query(7, ge=1, le=30),
):
    if not endpoint and not iflow_id:
        raise HTTPException(status_code=400, detail="Provide endpoint or iflow_id")
    return _run(inspect_iflow, endpoint=endpoint, iflow_id=iflow_id, include_raw=raw,
                include_scripts=scripts, include_metrics=metrics, days=days)


@app.get("/search")
def search(name: str = Query(..., description="Part of iFlow name or ID")):
    items = _run(lambda c: c.find_by_name(name))
    return [{"id": s["Id"].split("$")[0], "name": s["Name"], "version": s["Version"]} for s in items]


@app.get("/metrics")
def metrics(iflow_id: str, days: int = Query(7, ge=1, le=30)):
    return _run(message_metrics, iflow_id, days=days)


@app.get("/profile")
def profile(endpoint: str = Query(None), iflow_id: str = Query(None)):
    if not endpoint and not iflow_id:
        raise HTTPException(status_code=400, detail="Provide endpoint or iflow_id")
    return _run(build_profile, endpoint=endpoint, iflow_id=iflow_id)


@app.get("/profile/export")
def export_profile(endpoint: str = Query(None), iflow_id: str = Query(None)):
    if not endpoint and not iflow_id:
        raise HTTPException(status_code=400, detail="Provide endpoint or iflow_id")
    p = _run(build_profile, endpoint=endpoint, iflow_id=iflow_id)
    wb = Workbook()
    ws = wb.active
    ws.title = "Interface profile"
    ws.append(["#", "Parameter", "Value", "Source", "Hint"])
    for f in p["fields"]:
        val = f["value"]
        ws.append([f["no"], f["name"], json.dumps(val) if isinstance(val, (dict, list)) else val,
                   f["source"], f.get("hint")])
    ws.column_dimensions["B"].width = 38
    ws.column_dimensions["C"].width = 80
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return StreamingResponse(
        buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=interface_profile.xlsx"})
