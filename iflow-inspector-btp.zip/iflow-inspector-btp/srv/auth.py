"""FastAPI dependency: every route (except /health) needs a valid XSUAA token with the Viewer scope."""
import os

from fastapi import HTTPException, Request

import authcore

_CRED = authcore.xsuaa_credentials()
# No XSUAA binding: allowed only for local development (not on Cloud Foundry) or when explicitly enabled.
_ANON = os.getenv("ALLOW_ANONYMOUS", "").lower() == "true" or not os.getenv("VCAP_APPLICATION")


def require_auth(request: Request):
    if request.url.path == "/health":
        return
    if _CRED is None:
        if _ANON:
            request.state.user = "anonymous (local)"
            return
        raise HTTPException(status_code=503, detail="Authentication not configured: bind the XSUAA service")
    header = request.headers.get("authorization", "")
    if not header.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Missing bearer token. Open the app through the app router URL.")
    try:
        claims = authcore.verify(header[7:], _CRED)
    except authcore.AuthError as e:
        raise HTTPException(status_code=e.status, detail=e.detail)
    request.state.user = claims.get("user_name") or claims.get("email") or claims.get("client_id")
