"""Offline test: fake iFlow zip and fake CPI client (no network, no BTP needed).
Run from the project folder:  python tests/test_offline.py
"""
import io, os, sys, zipfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import cpi
from iface_profile import build_profile, FIELD_NAMES

def prop(k, v):
    return "<ifl:property><key>%s</key><value>%s</value></ifl:property>" % (k, v)

IFLX = """<?xml version="1.0" encoding="UTF-8"?>
<bpmn2:definitions xmlns:bpmn2="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:ifl="http:///com.sap.ifl.model/Ifl.xsd">
 <bpmn2:collaboration id="C1">
  <bpmn2:messageFlow id="MF1" name="HTTPS_in"><bpmn2:extensionElements>%s%s%s%s</bpmn2:extensionElements></bpmn2:messageFlow>
  <bpmn2:messageFlow id="MF2" name="S4_out"><bpmn2:extensionElements>%s%s%s%s%s%s</bpmn2:extensionElements></bpmn2:messageFlow>
 </bpmn2:collaboration>
 <bpmn2:process id="P1" name="Integration Process">
  <bpmn2:startEvent id="S" name="Start"><bpmn2:extensionElements>%s</bpmn2:extensionElements></bpmn2:startEvent>
  <bpmn2:callActivity id="A1" name="Set Headers"><bpmn2:extensionElements>%s%s</bpmn2:extensionElements></bpmn2:callActivity>
  <bpmn2:callActivity id="A2" name="Transform"><bpmn2:extensionElements>%s%s</bpmn2:extensionElements></bpmn2:callActivity>
  <bpmn2:exclusiveGateway id="G" name="Route"><bpmn2:extensionElements>%s</bpmn2:extensionElements></bpmn2:exclusiveGateway>
  <bpmn2:serviceTask id="T" name="Call S4"><bpmn2:extensionElements>%s</bpmn2:extensionElements></bpmn2:serviceTask>
  <bpmn2:endEvent id="E" name="End"/>
  <bpmn2:sequenceFlow id="F1" sourceRef="S" targetRef="A1"/>
  <bpmn2:sequenceFlow id="F2" sourceRef="A1" targetRef="A2"/>
  <bpmn2:sequenceFlow id="F3" sourceRef="A2" targetRef="G"/>
  <bpmn2:sequenceFlow id="F4" sourceRef="G" targetRef="T" name="type A"><bpmn2:conditionExpression>${header.type} = 'A'</bpmn2:conditionExpression></bpmn2:sequenceFlow>
  <bpmn2:sequenceFlow id="F5" sourceRef="G" targetRef="E" name="default"><bpmn2:extensionElements>%s</bpmn2:extensionElements></bpmn2:sequenceFlow>
  <bpmn2:sequenceFlow id="F6" sourceRef="T" targetRef="E"/>
  <bpmn2:subProcess id="X" name="Exception Subprocess 1"><bpmn2:extensionElements>%s</bpmn2:extensionElements>
    <bpmn2:startEvent id="XS" name="Error Start"/></bpmn2:subProcess>
 </bpmn2:process>
</bpmn2:definitions>""" % (
    prop("direction", "Sender"), prop("ComponentType", "HTTPS"), prop("TransportProtocol", "HTTP"), prop("senderAuthType", "RoleBased"),
    prop("direction", "Receiver"), prop("ComponentType", "ODataV2"), prop("TransportProtocol", "HTTP"),
    prop("address", "{{s4url}}/sap/opu/odata"), prop("authenticationMethod", "Basic"), prop("credentialName", "S4_CRED"),
    prop("activityType", "StartEvent"),
    prop("activityType", "Enricher"), prop("headerTable", "&lt;row&gt;&lt;/row&gt;".replace("&lt;", "<").replace("&gt;", ">")),
    prop("activityType", "Mapping"), prop("mappingname", "Order_Map"),
    prop("activityType", "ExclusiveGateway"),
    prop("activityType", "ExternalCall"),
    prop("isDefault", "true"),
    prop("activityType", "ErrorEventSubProcessTemplate"))

def make_zip():
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w") as z:
        z.writestr("src/main/resources/scenarioflows/integrationflow/Order_to_S4.iflx", IFLX)
        z.writestr("src/main/resources/mapping/Order_Map.mmap", "<x/>")
        z.writestr("src/main/resources/script/t.groovy", "def x=1")
    return zipfile.ZipFile(io.BytesIO(b.getvalue()))

class Fake(cpi.CPI):
    def __init__(self): pass
    def find_iflow(self, url): return {"Id": "Order_to_S4$endpointAddress=orders", "Name": "Order to S4", "Version": "1.0.3"}
    def find_package(self, i): return "SalesPkg", "Sales Integration"
    def download_iflow(self, i): return make_zip()
    def configurations(self, i): return {"s4url": "https://s4.example.com", "api_password": "x"}
    def runtime_status(self, i): return {"status": "STARTED", "deployed_by": "u", "deployed_on": "d"}
    def design_artifact(self, i): return {"Version": "1.0.3", "PackageId": "SalesPkg", "Description": "Orders to S4",
        "Sender": "Webshop", "Receiver": "S/4HANA", "CreatedBy": "a", "ModifiedBy": "b", "CreatedAt": "/Date(1700000000000)/", "ModifiedAt": "/Date(1700000000000)/"}
    def get(self, path, accept="application/json"):
        class R:
            def json(s): return {"d": {"results": [
                {"Status": "COMPLETED", "LogStart": "/Date(1700000000000)/", "LogEnd": "/Date(1700000000400)/", "MessageGuid": "g1"},
                {"Status": "FAILED", "LogStart": "/Date(1700003600000)/", "LogEnd": "/Date(1700003600100)/", "MessageGuid": "g2"}]}}
            text = "HTTP 503 from receiver\nmore"
        return R()

z = make_zip()
ad = cpi.parse_iflow(z)
assert [a["direction"] for a in ad] == ["Sender", "Receiver"], ad
ps = cpi.parse_steps(z, {"s4url": "u"})
names = [s["name"] for s in ps[0]["steps"]]
print("step order:", names)
assert names[:5] == ["Start", "Set Headers", "Transform", "Route", "Call S4"], names
router = next(s for s in ps[0]["steps"] if s["palette_step"] == "Router")
assert router["routes"][0]["condition"] and router["routes"][1]["default"]

prof = build_profile(Fake(), endpoint="https://x/http/orders", catalog={"_defaults": {"Environment": "Dev"}, "Order_to_S4": {"Business Owner": "Jane"}})
assert prof["artifact_id"] == "Order_to_S4", prof["artifact_id"]
assert len(prof["fields"]) == 32 and [f["name"] for f in prof["fields"]] == FIELD_NAMES
by = {f["name"]: f for f in prof["fields"]}
assert by["Business Owner"]["value"] == "Jane" and by["Environment"]["value"] == "Dev"
assert by["Externalized Parameters"]["value"]["api_password"] == "****"
assert "S4_CRED" in by["Security Material Alias"]["value"]
print("summary:", prof["summary"])
for k in ("Source System", "Target System", "Authentication Method", "Processing Pattern", "Mapping / Transformation", "Message Volume (Avg/Peak)", "Error Handling / Retry", "Lifecycle Status"):
    print(" -", k, "=>", by[k]["value"])
print("ALL OFFLINE TESTS PASSED")
