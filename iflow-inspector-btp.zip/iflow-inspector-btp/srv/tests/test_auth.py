"""Offline tests for token validation and credential selection. Run: python tests/test_auth.py"""
import json, os, sys, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import jwt
from cryptography.hazmat.primitives.asymmetric import rsa

import authcore
import cpi

key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
CRED = {"xsappname": "iflow-inspector!t1234", "clientid": "c", "url": "https://x.authentication.us10.hana.ondemand.com"}
pub = lambda token, cred: key.public_key()

def token(scope, exp=3600, signer=key):
    return jwt.encode({"scope": scope, "user_name": "jane", "exp": int(time.time()) + exp}, signer, algorithm="RS256")

ok = authcore.verify(token(["iflow-inspector!t1234.Viewer"]), CRED, key_func=pub)
assert ok["user_name"] == "jane"

def expect(status, tok):
    try:
        authcore.verify(tok, CRED, key_func=pub)
    except authcore.AuthError as e:
        assert e.status == status, (e.status, e.detail)
        return
    raise AssertionError("expected AuthError %s" % status)

expect(403, token(["other!t1.Viewer"]))             # right signature, wrong scope
expect(403, token([]))                               # no scopes
expect(401, token(["iflow-inspector!t1234.Viewer"], exp=-10))   # expired
other = rsa.generate_private_key(public_exponent=65537, key_size=2048)
expect(401, token(["iflow-inspector!t1234.Viewer"], signer=other))  # signed by a different key
expect(401, "not-a-token")
print("token validation: ok")

# credential selection from VCAP_SERVICES: must skip XSUAA and pick the api binding
vcap = {
  "xsuaa": [{"name": "iflow-inspector-uaa", "credentials": {"xsappname": "a", "clientid": "uaa-id", "clientsecret": "s", "url": "https://uaa", "tokenurl": "https://uaa/oauth/token"}}],
  "process-integration-runtime": [
    {"name": "other-flow-binding", "credentials": {"oauth": {"clientid": "wrong", "clientsecret": "s", "tokenurl": "https://t", "url": "https://wrong"}}},
    {"name": "iflow-inspector-api", "credentials": {"oauth": {"clientid": "right", "clientsecret": "sec", "tokenurl": "https://t/oauth/token", "url": "https://api-host"}}}]}
os.environ["VCAP_SERVICES"] = json.dumps(vcap)
url, tok_url, cid, sec = cpi.load_credentials()
assert (url, cid, sec) == ("https://api-host", "right", "sec"), (url, cid)
assert authcore.xsuaa_credentials()["clientid"] == "uaa-id"
print("credential selection: ok")
print("ALL AUTH TESTS PASSED")
