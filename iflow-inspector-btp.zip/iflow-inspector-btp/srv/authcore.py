"""JWT validation for XSUAA tokens (no web framework needed, so it is easy to test)."""
import json
import os

import jwt
from jwt import PyJWKClient


class AuthError(Exception):
    def __init__(self, status, detail):
        super().__init__(detail)
        self.status, self.detail = status, detail


def xsuaa_credentials():
    """Credentials of the bound XSUAA instance, or None if not bound."""
    vcap = os.getenv("VCAP_SERVICES")
    if not vcap:
        return None
    for _, instances in json.loads(vcap).items():
        for inst in instances:
            c = inst.get("credentials", {})
            if c.get("xsappname") and c.get("clientid") and c.get("url"):
                return c
    return None


_clients = {}


def _signing_key(token, cred):
    base = cred["url"].rstrip("/")
    if base not in _clients:
        _clients[base] = PyJWKClient(base + "/token_keys")
    return _clients[base].get_signing_key_from_jwt(token).key


def verify(token, cred, scope="Viewer", key_func=_signing_key):
    """Check signature and expiry, then require scope '<xsappname>.<scope>'. Returns the claims."""
    try:
        key = key_func(token, cred)
        claims = jwt.decode(token, key, algorithms=["RS256"], options={"verify_aud": False})
    except jwt.ExpiredSignatureError:
        raise AuthError(401, "Token expired")
    except Exception:
        raise AuthError(401, "Invalid token")
    required = "%s.%s" % (cred["xsappname"], scope)
    if required not in (claims.get("scope") or []):
        raise AuthError(403, "Missing scope %s. Assign the 'iFlow Inspector Viewer' role collection." % required)
    return claims
