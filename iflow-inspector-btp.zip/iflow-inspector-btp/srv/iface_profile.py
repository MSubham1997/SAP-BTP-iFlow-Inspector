"""Builds the 32-parameter interface profile for an iFlow."""
import json
import os
import re

from cpi import flatten, inspect_iflow

FIELD_NAMES = [
    "Interface ID", "Artifact Type", "Package / API Product", "Artifact Name",
    "Functional Workstream", "Interface Description / Functionality", "Source System",
    "Target System", "Direction", "Business Object", "Source Protocol", "Target Protocol",
    "Message Format", "Trigger / Frequency", "Authentication Method", "Security Material Alias",
    "Endpoint / Base Path", "Externalized Parameters", "Processing Pattern",
    "Mapping / Transformation", "Message Volume (Avg/Peak)", "Alert Notification",
    "Error Handling / Retry", "Monitoring Method", "Business Owner", "Technical Owner",
    "Environment", "Lifecycle Status", "Criticality", "SLA / Performance Target",
    "Data Classification", "Support / Runbook Reference",
]
SECRET_HINTS = ("password", "secret", "token", "apikey", "api_key")


def load_catalog(path=None):
    path = path or os.getenv("CATALOG_FILE", "catalog.json")
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    return {}


def _first(props, *keys):
    for k in keys:
        if props.get(k):
            return props[k]
    return None


def _join(values):
    vals = [str(v) for v in values if v]
    return "; ".join(dict.fromkeys(vals)) or None


def _proto(a):
    return " / ".join(x for x in (a.get("adapter"), a.get("transport")) if x) or None


def _mask(params):
    return {k: ("****" if any(h in k.lower() for h in SECRET_HINTS) else v) for k, v in params.items()}


def build_profile(cpi, endpoint=None, iflow_id=None, catalog=None):
    info = inspect_iflow(cpi, endpoint=endpoint, iflow_id=iflow_id, include_raw=True,
                         include_metrics=True, days=30)
    if "error" in info:
        return info
    catalog = load_catalog() if catalog is None else catalog
    entry = {**catalog.get("_defaults", {}), **catalog.get(info["artifact_id"], {})}

    m = info.get("metrics", {})
    design, rt, cx, dep = m.get("design", {}), m.get("runtime", {}), m.get("complexity", {}), m.get("deployment") or {}
    senders, receivers = info["senders"], info["receivers"]
    sprops = [a.get("raw", {}) for a in senders]
    rprops = [a.get("raw", {}) for a in receivers]
    steps = [s for p in info["processes"] for s in flatten(p["steps"])]
    types = {s["palette_step"] for s in steps}
    rec = {}

    def put(name, value, source, hint=None):
        rec[name] = {"value": value, "source": source if value else "missing", "hint": hint}

    put("Interface ID", info["artifact_id"], "derived")
    put("Artifact Type", "Integration Flow", "auto")
    put("Package / API Product", _join([info["package_name"], info["package_id"]]), "auto")
    put("Artifact Name", info["artifact_name"], "auto")
    put("Functional Workstream", None, "catalog", "Package name: %s" % info["package_name"])
    put("Interface Description / Functionality", design.get("description"), "auto")

    put("Source System", design.get("sender") or _join(a.get("name") or a.get("address") for a in senders),
        "auto" if design.get("sender") else "derived")
    put("Target System", design.get("receiver") or _join(a.get("name") or a.get("address") for a in receivers),
        "auto" if design.get("receiver") else "derived")
    bidir = "Request Reply / Content Enricher" in types
    put("Direction", "Bidirectional (request-reply)" if bidir else "Source to target (one-way)", "derived")
    put("Business Object", None, "catalog")

    put("Source Protocol", _join(_proto(a) for a in senders), "auto")
    put("Target Protocol", _join(_proto(a) for a in receivers), "auto")
    fmts = [a.get("message_protocol") for a in senders + receivers]
    fmts += [t for t in types if "Converter" in t or t == "Mapping"]
    put("Message Format", _join(fmts), "derived")

    schedule = next((str(v)[:150] for s in steps if s["element"] == "startEvent"
                     for k, v in s["config"].items() if "schedul" in k.lower() and v), None)
    poll = _join(str(v)[:150] for p in sprops for k, v in p.items() if v and re.search("poll|schedul", k, re.I))
    put("Trigger / Frequency",
        ("Scheduled: " + schedule) if schedule else ("Polling: " + poll) if poll else "Event-driven (real time)",
        "derived")

    auth_s = _join(_first(p, "senderAuthType", "authenticationType", "authenticationMethod") for p in sprops)
    auth_r = _join(_first(p, "authenticationMethod", "authenticationType") for p in rprops)
    put("Authentication Method",
        _join(["Sender: " + auth_s if auth_s else None, "Receiver: " + auth_r if auth_r else None]), "auto")
    put("Security Material Alias",
        _join(v for p in sprops + rprops for k, v in p.items()
              if v and re.search("credential|alias", k, re.I) and v not in ("true", "false")), "auto")
    put("Endpoint / Base Path", _join([endpoint] + [a.get("address") for a in receivers]), "auto")

    put("Externalized Parameters", _mask(info.get("parameters", {})) or None, "auto")
    pattern = ["Synchronous (request-reply)" if bidir else "Asynchronous / one-way"]
    for t, label in (("Router", "Content-based routing"), ("Splitter", "Split"), ("Gather", "Gather"),
                     ("Multicast", "Multicast"), ("Aggregator", "Aggregation")):
        if t in types:
            pattern.append(label)
    if schedule:
        pattern.append("Scheduled")
    put("Processing Pattern", _join(pattern), "derived")
    put("Mapping / Transformation",
        _join("%s (%s)" % (s["config"].get("mappingname") or s["config"].get("script") or s["name"],
                           s["palette_step"])
              for s in steps if s["palette_step"] in ("Mapping", "Script", "XML to JSON Converter",
                                                      "JSON to XML Converter")), "auto")

    v = rt.get("volume") or {}
    put("Message Volume (Avg/Peak)",
        "Avg %s/day; peak %s/hour (%s); peak %s/day, last %s days" % (
            v.get("avg_per_day"), v.get("peak_per_hour"), v.get("peak_hour"), v.get("peak_per_day"),
            rt.get("period_days")) if v else None, "auto")

    mail = any((a.get("adapter") or "").lower() == "mail" for a in receivers)
    put("Alert Notification", "Email via Mail receiver adapter" if mail else None, "derived",
        "Alerts are usually configured outside the iFlow; add the alert target in the catalog")
    retry_cfg = _join("%s=%s" % (k, val) for p in sprops + rprops for k, val in p.items()
                      if val and re.search("retry|deadLetter|exponential", k, re.I))
    put("Error Handling / Retry",
        _join(["Exception subprocess present" if cx.get("has_exception_subprocess") else "No exception subprocess",
               retry_cfg, "Messages in RETRY (30 days): %s" % rt.get("by_status", {}).get("RETRY", 0)]),
        "derived")
    put("Monitoring Method", "Cloud Integration message monitoring", "derived")

    put("Business Owner", None, "catalog")
    put("Technical Owner", None, "catalog", "Last modified by: %s" % design.get("modified_by"))
    put("Environment", os.getenv("ENVIRONMENT"), "catalog")
    status = dep.get("status")
    put("Lifecycle Status", "Active (deployed: %s)" % status if status == "STARTED" else status, "derived")
    put("Criticality", None, "catalog")
    put("SLA / Performance Target", None, "catalog",
        "Observed p95: %s ms" % (rt.get("processing_time_ms") or {}).get("p95"))
    put("Data Classification", None, "catalog")
    put("Support / Runbook Reference", None, "catalog")

    for name in FIELD_NAMES:
        if name in entry:
            rec[name] = {"value": entry[name], "source": "catalog", "hint": None}

    fields = [{"no": i, "name": n, **rec[n]} for i, n in enumerate(FIELD_NAMES, 1)]
    counts = {}
    for f in fields:
        counts[f["source"]] = counts.get(f["source"], 0) + 1
    return {"artifact_id": info["artifact_id"], "summary": counts, "fields": fields}
