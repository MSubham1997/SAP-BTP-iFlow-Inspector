# iFlow Inspector - SAP BTP edition

Everything runs on BTP Cloud Foundry:

| Part | What | Where |
|---|---|---|
| Backend + UI | FastAPI app (Python) | `srv/` |
| Login | XSUAA (plan application), role collection "iFlow Inspector Viewer" | `xs-security.json` |
| Entry point | Application router (Node) - users open this URL | `approuter/` |
| Cloud Integration access | Process Integration Runtime, plan api (bound to the backend) | created by `deploy.sh` |
| Business catalog | `srv/catalog.json` (bundled with the app) | see "Catalog" |

Flow: user -> app router (login via XSUAA) -> backend (checks token + Viewer scope) -> Cloud Integration API.
No secrets in code: credentials come from service bindings (VCAP_SERVICES).

## Prerequisites
- Cloud Foundry CLI v8 (`cf --version`) and you can run `cf login` for your subaccount/space
- A Cloud Foundry space in your subaccount (trial: org/space "dev")
- Entitlements for: XSUAA (application), Process Integration Runtime (api), 2 apps x 256 MB

## Deploy (Mac/Linux)
    cf login -a https://api.cf.us10-001.hana.ondemand.com      # use your region's API endpoint
    cd iflow-inspector-btp
    ./deploy.sh
The script creates the two services, pushes backend and app router, connects them, and prints the app URL.
(Windows: run it in Git Bash or WSL.)

## After deploy
1. BTP Cockpit > Security > Users > your user > Assign Role Collection: **iFlow Inspector Viewer**
2. Open the app router URL, log in, paste an iFlow endpoint, click Inspect.
3. `<app-router-url>/me` shows who you are logged in as (debug aid).

## Useful commands
    cf apps                                  # states and URLs
    cf logs iflow-inspector-srv --recent     # backend log
    cf env iflow-inspector-srv               # bindings (contains secrets - do not share)

## If your Process Integration Runtime instance is NOT in the Cloud Foundry space
(e.g. created under "Instances and Subscriptions" in "other environments"): create a user-provided
service with the service key values instead, BEFORE running deploy.sh:
    cf create-user-provided-service iflow-inspector-api -p '{"oauth":{"url":"<url>","tokenurl":"<tokenurl>","clientid":"<clientid>","clientsecret":"<clientsecret>"}}'
(Use single quotes. deploy.sh skips creating the service if the name already exists.)

## Alternative: MTA deployment
`mta.yaml` describes the same system. Needs `mbt` and the MultiApps plugin:
    mbt build && cf deploy mta_archives/iflow-inspector_1.0.0.mtar
The Python module build settings in mta.yaml are untested; if `mbt build` complains, use `deploy.sh`.

## Catalog (owners, criticality, SLA ...)
Edit `srv/catalog.json`, then `cf push -f manifest-srv.yml`. Moving it into a database (HANA Cloud)
is the next step if many people need to edit it; note HANA Cloud on trial must be restarted daily.

## Local run (no login needed)
    cd srv && python3 -m venv venv && source venv/bin/activate && python -m pip install -r requirements.txt
    export CPI_URL='..' CPI_TOKEN_URL='..' CPI_CLIENT_ID='..' CPI_CLIENT_SECRET='..'
    uvicorn main:app --reload        # http://127.0.0.1:8000
Local runs skip authentication only when not on Cloud Foundry.

## Tests (offline)
    cd srv && python tests/test_offline.py && python tests/test_auth.py

## Remove everything
    cf delete iflow-inspector-approuter -f; cf delete iflow-inspector-srv -f
    cf delete-service iflow-inspector-uaa -f; cf delete-service iflow-inspector-api -f

## Troubleshooting
| Symptom | Cause / fix |
|---|---|
| 403 "Missing scope" | Role collection not assigned to you; assign it, log out and in again |
| 401 "Missing bearer token" | You opened the backend URL directly; use the app router URL |
| 503 "Authentication not configured" | XSUAA not bound to the backend; `cf bind-service iflow-inspector-srv iflow-inspector-uaa` and restage |
| Login redirect error | Redirect URI in `xs-security.json` must match your region domain (default cfapps.us10-001...); update and `cf update-service iflow-inspector-uaa -c xs-security.json` |
| 502 Cloud Integration API error 403 | Add the missing role to the api instance parameters |
| Services not found in marketplace | Missing entitlement in the subaccount (Entitlements) |
